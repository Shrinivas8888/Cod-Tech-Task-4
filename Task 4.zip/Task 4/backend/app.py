from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS  # ✅ Import CORS
import json
from datetime import datetime

app = Flask(__name__)
CORS(app)  # ✅ Enable CORS for all routes

DATA_FILE = 'database.json'
PRODUCTIVE_SITES = ['github.com', 'stackoverflow.com', 'leetcode.com', 'replit.com']

def load_data():
    try:
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    except:
        return {}

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

@app.route('/')
def home():
    return '<h2>Welcome to Time Tracker Backend</h2><a href="/dashboard">Go to Dashboard</a>'

@app.route('/track', methods=['POST'])
def track_time():
    data = request.json
    url = data['url']
    duration = data['duration']

    db = load_data()
    today = datetime.now().strftime('%Y-%m-%d')
    if today not in db:
        db[today] = {}

    if url not in db[today]:
        db[today][url] = 0

    db[today][url] += duration
    save_data(db)
    return jsonify({'status': 'success'})

@app.route('/dashboard')
def dashboard():
    db = load_data()
    html = "<h1>Weekly Productivity Report</h1>"

    for date, sites in db.items():
        html += f"<h3>{date}</h3><ul>"
        total = 0
        productive = 0
        for site, time in sites.items():
            mins = round(time / 60, 2)
            total += time
            if site in PRODUCTIVE_SITES:
                productive += time
            html += f"<li>{site}: {mins} min</li>"
        prod_score = round((productive / total) * 100, 2) if total else 0
        html += f"</ul><strong>Productivity: {prod_score}%</strong><hr>"

    return render_template_string(html)

if __name__ == '__main__':
    app.run(debug=True)
