let activeTabId = null;
let activeStartTime = null;

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const now = Date.now();

  if (activeTabId !== null && activeStartTime !== null) {
    const duration = (now - activeStartTime) / 1000;

    chrome.tabs.get(activeTabId, (tab) => {
      if (tab && tab.url.startsWith("http")) {
        fetch("http://localhost:5000/track", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            url: new URL(tab.url).hostname,
            duration: duration
          })
        });
      }
    });
  }

  activeTabId = activeInfo.tabId;
  activeStartTime = now;
});