document.getElementById("viewDashboard").onclick = () => {
  chrome.tabs.create({ url: "http://localhost:5000/dashboard" });
};